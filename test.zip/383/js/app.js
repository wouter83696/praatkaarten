// Zorg dat "viewport units" op mobiel/rotatie altijd kloppen (iOS/Safari quirks)
function setVh(){
  const vh = window.innerHeight * 0.01;
  document.documentElement.style.setProperty('--vh', `${vh}px`);
}
setVh();

// ===============================
// Path-resolver (werkt in ELKE directory op GitHub Pages)
// - probeert eerst huidige directory
// - daarna repo-root (bijv. /praatkaarten/)
// - daarna (optioneel) parent directories
// ===============================
function getRepoRoot(){
  const parts = location.pathname.split('/').filter(Boolean);
  // GitHub Pages project site: eerste segment is repo-name
  // /<repo>/... -> repo root = /<repo>/
  if(parts.length>=1) return `/${parts[0]}/`;
  return '/';
}
function currentDirUrl(){
  return new URL('./', location.href);
}
function resolveResourceUrl(rel){
  const relClean = rel.replace(/^\//,''); // nooit absolute slash
  const tries = [];
  const cur = currentDirUrl();
  tries.push(new URL(relClean, cur));

  // probeer parent directories (max 3 niveaus) voor het geval je nested test-mappen hebt
  let parent = cur;
  for(let i=0;i<3;i++){
    parent = new URL('../', parent);
    tries.push(new URL(relClean, parent));
  }

  // repo root als laatste (meest stabiel)
  const repoRoot = new URL(getRepoRoot(), location.origin);
  tries.push(new URL(relClean, repoRoot));

  // ook repoRoot + "praatkaarten-main/" fallback (voor oudere structuren)
  tries.push(new URL(`praatkaarten-main/${relClean}`, repoRoot));

  return tries;
}

// ===============================
// Set-structuur (fool proof)
// - Voeg nieuwe sets toe in /sets/<setnaam>/
// - Kies set via URL: ?set=samenwerken  (default: samenwerken)
// ===============================
function getActiveSet(){
  try{
    const sp = new URL(location.href).searchParams;
    const s = (sp.get('set') || 'samenwerken').trim();
    return s || 'samenwerken';
  }catch(e){
    return 'samenwerken';
  }
}
const ACTIVE_SET = getActiveSet();
const SET_BASE  = `sets/${ACTIVE_SET}/`;
const SET_CARDS = `${SET_BASE}cards/`;
function setPath(rel){
  const clean = String(rel||'').replace(/^\/+/, '');
  return `${SET_BASE}${clean}`;
}
function cardPath(file){
  const clean = String(file||'').replace(/^\/+/, '');
  return `${SET_CARDS}${clean}`;
}
async function fetchJsonFallback(rel){
  const urls = resolveResourceUrl(rel);
  let lastErr = null;
  for(const u of urls){
    try{
      const r = await fetch(u.toString(), { cache: 'no-store' });
      if(r.ok) return await r.json();
      lastErr = new Error(`HTTP ${r.status} for ${u}`);
    }catch(e){
      lastErr = e;
    }
  }
  throw lastErr || new Error(`Kon ${rel} niet laden`);
}
async function fetchTextFallback(rel){
  const urls = resolveResourceUrl(rel);
  let lastErr = null;
  for(const u of urls){
    try{
      const r = await fetch(u.toString(), { cache: 'no-store' });
      if(r.ok) return await r.text();
      lastErr = new Error(`HTTP ${r.status} for ${u}`);
    }catch(e){
      lastErr = e;
    }
  }
  throw lastErr || new Error(`Kon ${rel} niet laden`);
}
window.addEventListener('resize', setVh);
window.addEventListener('orientationchange', setVh);
if (window.visualViewport){
  window.visualViewport.addEventListener('resize', setVh);
}

// Versie + cache-buster (handig op GitHub Pages)
// Versie (ook gebruikt als cache-buster op GitHub Pages)
// Houd versie gelijk aan index-badge (GitHub cache-buster)
// v3.6.1 – rebuild fix: uitleg-sheet + close buttons
const VERSION = '3.8.3';
const withV = (url) => url + (url.includes('?') ? '&' : '?') + 'v=' + encodeURIComponent(VERSION);

// Definitieve set (v3.6.5): Verdiepen is hernoemd naar Verhelderen.
const THEMES = ["verkennen","duiden","verbinden","verhelderen","vertragen","bewegen"];

  // State
  let data = [];
  let filtered = [];      // huidige (eventueel gehusselde) kaartset
  let helpFiltered = [];  // uitlegkaartjes
  let currentIndex = -1;


  const grid = document.getElementById('grid');
  const lb = document.getElementById('lb');
  const lbImg = document.getElementById('lbImg');
  const lbText = document.getElementById('lbText');
  const lbCard = document.getElementById('lbCard');
  const themeTag = document.getElementById('themeTag');
  // (v3.3.7) swipe-hint is bewust verwijderd
  const navHint = null;

  const closeBtn = document.getElementById('lbClose');
  const prevBtn = document.getElementById('prev');
  const nextBtn = document.getElementById('next');

  // Onderbalk: chips (v3.2)
  const shuffleBtn = document.getElementById('shuffleBtn');
  const uitlegBtn  = document.getElementById('uitlegBtn');
  // (v3.3.7) geen extra sluitknoppen in de pills
  const mobileIntroEl = document.getElementById('mobileIntro');

  let shuffleOn = false;
  let uitlegOn  = false;

  function setChip(btn, on){
    if(!btn) return;
    btn.classList.toggle('is-on', !!on);
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
  }

  function isMobile(){
    return !!(window.matchMedia && window.matchMedia('(max-width: 720px)').matches);
  }
  const lbHelpText = document.getElementById('lbHelpText');
  const lbHelpTitle = document.getElementById('lbHelpTitle');
  const lbHelpDesc = document.getElementById('lbHelpDesc');

  // POSITION OVERLAY CLOSE (mobiel/desktop)
  // Zorg dat het kruisje (én de hitbox) altijd bovenop de kaart ligt.
  // Close knop (opnieuw geplaatst)
  const overlayClose = document.getElementById('lbClose');
  const overlayCloseHitbox = document.getElementById('lbCloseHitbox');
  function positionOverlayClose(){
    // In deze build staat het kruisje "vast" (position: fixed) rechtsboven in de viewport.
    // Dus we hoeven niets te positioneren via JS. (Dit voorkomt gezeik met transforms/gesture layers.)
    return;
  }
  window.addEventListener('resize', positionOverlayClose, {passive:true});
  window.addEventListener('scroll', positionOverlayClose, {passive:true});

  // In de uitleg willen we GEEN extra kop boven de tekst (alleen de beschrijving).
  if(lbHelpTitle){
    lbHelpTitle.textContent = "";
    lbHelpTitle.style.display = "none";
  }

  

  let mode = 'cards'; // 'cards' of 'help'
  let helpData = {};

  function firstSentence(txt){
    const t = String(txt || "").trim().replace(/\s+/g,' ');
    const m = t.match(/^[\s\S]*?[.!?]/);
    return m ? m[0].trim() : t;
  }
  // Uitleg-modus: voorkant + 6 thema-kaarten (alles in dezelfde lightbox).
  const helpItems = [
    { theme:'',            key:'cover',       bg:withV(cardPath('voorkant.svg')) },
    { theme:'Verkennen',   key:'verkennen',   bg:withV(cardPath('verkennen.svg')) },
    { theme:'Duiden',      key:'duiden',      bg:withV(cardPath('duiden.svg')) },
    { theme:'Verbinden',   key:'verbinden',   bg:withV(cardPath('verbinden.svg')) },
    { theme:'Verhelderen', key:'verhelderen', bg:withV(cardPath('verhelderen.svg')) },
    { theme:'Vertragen',   key:'vertragen',   bg:withV(cardPath('vertragen.svg')) },
    { theme:'Bewegen',     key:'bewegen',     bg:withV(cardPath('bewegen.svg')) }
  ];

  // (v3.3.7) swipe-hint verwijderd: geen timers/tekst meer
  let hintTimer = null;

// UI chrome (pijlen + sluiten)
  // - Touch: iets langer zichtbaar
  // - Desktop: ook auto-hide, maar alleen na inactiviteit (muis bewegen laat het weer zien)
  const HAS_HOVER = window.matchMedia && window.matchMedia('(hover: hover)').matches;
  const HIDE_MS_DESKTOP = 600;
  const HIDE_MS_TOUCH   = 900;

  let uiTimer = null;
  function showUI(){
    try{ positionOverlayClose(); }catch(_e){}

    lb.classList.add('show-ui');
    clearTimeout(uiTimer);
    const ms = HAS_HOVER ? HIDE_MS_DESKTOP : HIDE_MS_TOUCH;
    uiTimer = setTimeout(() => lb.classList.remove('show-ui'), ms);
  }

  function buildData(questions){
    const out = [];
    for (const theme of THEMES){
      const qs = questions[theme] || [];
      for (let i=0; i<qs.length; i++){
        out.push({
          theme,
          num: i+1,
          q: qs[i],
          bg: withV(cardPath(`${theme}.svg`)),
          id: `${theme}-${String(i+1).padStart(2,'0')}`
        });
      }
    }
    return out;
  }
  
  // ===============================
  // v3.3.47 – Init grid (portable)
  // - gebruikt embedded JSON (#questions-json) voor file://
  // - fallback: fetch data/data/questions.json voor hosting
  // - bouwt originele kaartjes (SVG achtergrond + tekst) zoals vóórheen
  // ===============================
  async function loadQuestions(){
  // 1) Probeer embedded JSON (werkt ook via file:// en voorkomt GitHub-pad-issues)
  try{
    const el = document.getElementById('questions-json');
    if(el && el.textContent && el.textContent.trim()){
      const parsed = JSON.parse(el.textContent);
      if(parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
    }
  }catch(e){ /* ignore */ }

  // 2) Fallback: fetch (voor hosting)
  try{
    const q = await fetchJsonFallback(setPath('questions.json'));
    if(!q || typeof q !== 'object' || Array.isArray(q)){
      throw new Error('questions.json heeft een onverwacht formaat (verwacht object per thema).');
    }
    return q;
  }catch(err){
    console.error('Kon data/questions.json niet laden.', err);
    showToast('Kan vragenlijst niet laden. Controleer of data/questions.json bestaat en of je via GitHub Pages of een lokale server draait.', 6000);
    return {};
  }
}

  (async function initGrid(){

    try{
      const q = await loadQuestions();
      if(!q || typeof q !== 'object'){
        // laat debug tekst i.p.v. leeg
        if(grid) grid.innerHTML = '<div style="padding:24px;font-family:system-ui;">Kon vragen niet laden.</div>';
        return;
      }
      data = buildData(q);
      // start zonder shuffle
      render(data.slice());
    }catch(e){
      console.error(e);
      if(grid) grid.innerHTML = '<div style="padding:24px;font-family:system-ui;">Fout bij laden.</div>';
    }
  })();

  function render(items){
    // Bewaar de huidige (zichtbare) kaartset voor navigatie
    filtered = items;
    grid.innerHTML = "";
    const frag = document.createDocumentFragment();

    items.forEach((item, idx) => {
      const btn = document.createElement('button');
      btn.className = 'card';
      btn.type = 'button';
      btn.setAttribute('aria-label', item.id);

      const inner = document.createElement('div');
      inner.className = 'cardInner';

      const img = document.createElement('img');
      img.className = 'bg';
      img.src = item.bg;
      img.alt = "";

      const q = document.createElement('div');
      q.className = 'q';
      // Tekst op een vast wit vlak (met extra wit onder de tekst)
      const qText = document.createElement('span');
      qText.className = 'qText';
      qText.textContent = item.q;
      q.appendChild(qText);

      inner.appendChild(img);
      inner.appendChild(q);
      btn.appendChild(inner);

      btn.addEventListener('click', () => {
        mode = 'cards';
        openAt(idx);
      });
      frag.appendChild(btn);
    });

    grid.appendChild(frag);
  }

  function setLightboxBackground(url){
    // Geblurde achtergrond = dezelfde SVG als huidige kaart
    // (werkt ook als de img zelf nog laadt)
    try{
      lb.style.setProperty('--lb-bg-url', `url("${url}")`);
    }catch(_e){}
  }

  function openLb(item){
    // item: {bg, q} voor kaarten, of {bg, theme, key} voor help
    // FIX: gebruik de bg van het item (niet het <img>-element zelf), anders breekt klikken.
    const bg = (item && item.bg) ? String(item.bg).trim() : "";
    const bgResolved = (!bg)
      ? ""
      : (/^https?:\/\//i.test(bg) ? bg : resolveResourceUrl(bg)[0].toString());

    lbImg.src = bgResolved;
    if(bgResolved) setLightboxBackground(bgResolved);

    if(mode === 'help'){
      lb.classList.add('help');

      // UITLEG: toon uitlegtekst onder de kaart (titel onder kaart is via CSS verborgen)
      if(lbHelpText) lbHelpText.setAttribute('aria-hidden','false');
      // geen kop in uitleg
      const key = item.key;

      const raw = (helpData && key && typeof helpData[key] === 'string') ? helpData[key].trim() : "";
      // Geen geforceerde enters: laat de browser het netjes afbreken.
      const desc = firstSentence(raw.replace(/\s*\n\s*/g, ' '));
      if(lbHelpDesc) lbHelpDesc.textContent = desc;
      // In help-mode: thema-naam in het midden (net als op mobiel), behalve op de voorkant.
      const isCover = (item && item.key === 'cover');
      const t = (!isCover && item && typeof item.theme === 'string') ? item.theme.trim() : '';
      lbText.textContent = t;
      lb.classList.toggle('help-title', !!t);
      lb.classList.remove('no-overlay');
    }

    else{
      lb.classList.remove('help');
      if(lbHelpText) lbHelpText.setAttribute('aria-hidden','true');
      // geen kop in uitleg
      if(lbHelpDesc) lbHelpDesc.textContent = "";

      lbText.textContent = item.q || "";
    }

    lb.setAttribute('aria-hidden','false');
    lb.classList.add('open');
    try{ positionOverlayClose(); }catch(_e){}
document.body.classList.add('lb-open');

    // voorkom scrollen achter de lightbox (iOS/Safari vriendelijk)
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';

    showUI();
    // (v3.3.7) geen swipe-hint

    // Oneindig doorlopen: pijlen nooit uitschakelen
    if(prevBtn) prevBtn.disabled = false;
    if(nextBtn) nextBtn.disabled = false;
  }

  function closeLb(){
    // Sluiten = terug naar normale kaartmodus
    if(mode === 'help'){
      mode = 'cards';
      helpFiltered = [];
    }
    lb.classList.remove('help','no-overlay','help-title','open','show-ui');
    lbImg.src = "";
    lbText.textContent = "";
    if(lbHelpText) lbHelpText.setAttribute('aria-hidden','true');
    // geen kop in uitleg
    if(lbHelpDesc) lbHelpDesc.textContent = "";
    currentIndex = -1;
    lb.setAttribute('aria-hidden','true');
    document.body.classList.remove('lb-open');
    document.documentElement.style.overflow = '';
    document.body.style.overflow = '';
    // (v3.3.7) geen swipe-hint

    // Sync: als je de uitleg-lightbox op desktop sluit, zet de chip uit
    try{
      if(typeof isMobile === 'function' && !isMobile() && typeof uitlegOn !== 'undefined' && uitlegOn){
        uitlegOn = false;
        setChip(uitlegBtn, false);
      }
    }catch(_e){}
  }

  // Swipe / drag overal (ook op de grijze achtergrond):
  // - links/rechts: vorige/volgende
  // - omlaag: sluiten
  // - tap (touch): sluiten
  let startX = 0, startY = 0, startT = 0;
  let pointerDown = false;
  lb.classList.remove('is-swiping');
  let gestureArmed = false;
  let lastPointerType = 'mouse';

  // Voorkom dat de 'synthetic click' na een touch-tap doorvalt naar de grid
  // (klassieker: je sluit de lightbox, maar de klik opent direct weer een kaart).
  let suppressClickUntil = 0;

  function closeFromTap(e){
    suppressClickUntil = performance.now() + 450;
    try{ e?.preventDefault?.(); }catch(_e){}
    try{ e?.stopPropagation?.(); }catch(_e){}
    closeLb();
  }

  // Fallback: tap/click op de achtergrond (blur) sluit ook (handig als iOS pointer-events raar doet)
  const lbBg = lb.querySelector('.lbBg');
  if(lbBg){
    lbBg.addEventListener('click', (e) => {
      if(!lb.classList.contains('open')) return;
      // voorkom dubbele click na touch
      if(performance.now() < suppressClickUntil) return;
      closeFromTap(e);
    });
    lbBg.addEventListener('touchend', (e) => {
      if(!lb.classList.contains('open')) return;
      closeFromTap(e);
    }, {passive:false});
  }



  lb.addEventListener('pointerdown', (e) => {
    if(!lb.classList.contains('open')) return;
    lastPointerType = e.pointerType || 'mouse';
    // Als je start op een UI-knop (pijlen/sluiten), dan willen we géén swipe-gesture starten.
    // Als je start in het uitleg-tekstvak: laat verticale scroll met rust (geen swipe-gesture).
    // Anders kan een "klik" per ongeluk als swipe omlaag geïnterpreteerd worden en sluit het venster.
    if (e.target.closest && e.target.closest('button')) {
      gestureArmed = false;
      showUI();
      return;
    }
    if (e.target.closest && (e.target.closest('.lbHelpText') || e.target.closest('.lbHelpDesc'))){
      gestureArmed = false;
      return;
    }
    pointerDown = true;
    gestureArmed = true;
    startX = e.clientX;
    startY = e.clientY;
    startT = performance.now();
    // Op touch willen we native verticaal scrollen (zeker bij lange kaarten).
    // Pointer-capture kan dat soms "stroef" maken, dus alleen gebruiken bij mouse/pen.
    if(lastPointerType !== 'touch'){
      lb.setPointerCapture?.(e.pointerId);
    }
    showUI();
  });

  
lb.addEventListener('pointermove', (e) => {
  if(!pointerDown) return;
  if(!gestureArmed) return;

  const dx = e.clientX - startX;
  const dy = e.clientY - startY;
  const ax = Math.abs(dx);
  const ay = Math.abs(dy);

  // Alleen "swipe"-modus als het echt horizontaal is.
  // Dit voorkomt dat verticaal scrollen soms als swipe/tap wordt gezien.
  if(ax > ay && ax > 12){
    lb.classList.add('is-swiping');
  }
}, {passive:true});

lb.addEventListener('pointerup', (e) => {
    if(!pointerDown) return;
    pointerDown = false;
    lb.classList.remove('is-swiping');
    if(!gestureArmed) return;
    gestureArmed = false;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    const dt = performance.now() - startT;
    const ax = Math.abs(dx);
    const ay = Math.abs(dy);

    const fast = dt < 420;
    const thrX = fast ? 40 : 60;
    const thrY = fast ? 50 : 80;

    if(ay > ax && dy > thrY){
      closeLb();
      return;
    }
    if(ax > ay && ax > thrX){
      if(dx < 0) go(1); else go(-1);
      showUI();
      return;
    }

    // ✅ Tap-to-close op touch: ook als je op de kaart zelf tapt
    // (geen swipe, geen drag)
    if(lastPointerType !== 'mouse' && ax < 10 && ay < 10){
      closeFromTap(e);
      return;
    }
  });

  function activeItems(){
    return (mode === 'help') ? helpFiltered : filtered;
  }

  function openAt(index){
    const items = activeItems();
    currentIndex = index;
    openLb(items[currentIndex]);
  }

  function go(delta){

    if (currentIndex < 0) return;
    const items = activeItems();
    const total = items.length;
    let next = currentIndex + delta;
    if (next < 0) next = total - 1;
    if (next >= total) next = 0;
    openAt(next);
  }


  // Touch fallback (iOS/Safari): als Pointer Events niet (goed) werken, toch tap-to-close.
  let tStartX = 0, tStartY = 0;
  lb.addEventListener('touchstart', (e) => {
    if(!lb.classList.contains('open')) return;
    if (e.target.closest && e.target.closest('button')) return;
    const t = e.touches && e.touches[0];
    if(!t) return;
    tStartX = t.clientX;
    tStartY = t.clientY;
  }, {passive:true});

  lb.addEventListener('touchend', (e) => {
    if(!lb.classList.contains('open')) return;
    if (e.target.closest && e.target.closest('button')) return;
    const t = e.changedTouches && e.changedTouches[0];
    if(!t) return;
    const ax = Math.abs(t.clientX - tStartX);
    const ay = Math.abs(t.clientY - tStartY);
    // Alleen echte tap, geen swipe/drag
    if(ax < 10 && ay < 10){
      closeFromTap(e);
    }
  }, {passive:true});

  function shuffle(arr){
    for(let i=arr.length-1;i>0;i--){
      const j=Math.floor(Math.random()*(i+1));
      [arr[i],arr[j]]=[arr[j],arr[i]];
    }
    return arr;
  }

  // events (iconen op de kaart)
  // Belangrijk: desktop = klik op kaart doet niets (alleen UI tonen),
  // touch = tap op kaart sluit (tap-to-close).
  lbCard.addEventListener('click', (e) => {
    if ((window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || lastPointerType !== 'mouse') {
      closeFromTap(e);
      return;
    }
    e.stopPropagation();
  });
  // Sluiten moet altijd werken (ook op mobiel waar 'click' soms niet afvuurt)
  closeBtn.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); closeLb(); });
  closeBtn.addEventListener('pointerdown', (e) => {
    e.preventDefault();
    e.stopPropagation();
    closeLb();
  }, {capture:true});

  // Extra (onzichtbare) hitbox naast/om het kruisje voor makkelijke bediening op telefoon
  if(overlayCloseHitbox){
    overlayCloseHitbox.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); closeLb(); });
    overlayCloseHitbox.addEventListener('pointerdown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      closeLb();
    }, {capture:true});
  }
  prevBtn.addEventListener('click', (e) => { e.stopPropagation(); go(-1); showUI(); });
  nextBtn.addEventListener('click', (e) => { e.stopPropagation(); go(1); showUI(); });

  lb.addEventListener('mousemove', showUI);
  lb.addEventListener('touchstart', showUI, {passive:true});
  lb.addEventListener('click', (e) => {
    // Klik buiten de kaart (op de blur/achtergrond) = sluiten
    if(!lbCard.contains(e.target)) {
      if ((window.matchMedia && window.matchMedia('(pointer: coarse)').matches) || lastPointerType !== 'mouse') {
        closeFromTap(e);
      } else {
        closeLb();
      }
      return;
    }

    // Touch: klik op kaart wordt al door lbCard afgehandeld (tap-to-close)
    // Desktop: alleen UI tonen
    showUI();
  });

  // Onderdruk 'click-through' direct na een touch-tap-close.
  // Dit voorkomt dat er meteen weer een kaart opent op de plek waar je tikt.
  document.addEventListener('click', (e) => {
    // Alleen onderdrukken als de click buiten overlays/controls valt.
    // Anders kan bijvoorbeeld de close-knop soms "dood" aanvoelen op mobiel.
    if (
      performance.now() < suppressClickUntil &&
      !lb.contains(e.target) &&
      !(mobileIntroEl && mobileIntroEl.contains(e.target)) &&
      !(e.target && e.target.closest && e.target.closest('.pillsDock'))
    ) {
      e.stopPropagation();
      e.preventDefault();
    }
  }, true);
document.addEventListener('keydown', (e) => {
    if(!lb.classList.contains('open')) return;
    if(e.key === 'Escape') closeLb();
    if(e.key === 'ArrowLeft') go(-1);
    if(e.key === 'ArrowRight') go(1);
  });

  // ===============================
  // v3.2 – Chips onderbalk
  // (Let op: shuffleOn/uitlegOn, setChip() en isMobile() worden al bovenin gedeclareerd.)
  // - Hussel: aan = 1x shuffle, uit = originele volgorde
  // - Uitleg: mobiel = carousel boven grid, desktop = help-lightbox
  // ===============================

  function setUitleg(on){
    uitlegOn = !!on;
    setChip(uitlegBtn, uitlegOn);

    // Pills verplaatsen: onder ↔ boven
    document.body.classList.toggle('uitleg-open', uitlegOn);

    if(isMobile()){
      // Mobiel: bottom-sheet (uitleg carousel)
      if(uitlegOn) openIntroSheet();
      else closeIntroSheet();
      return;
    }

    // Desktop: help-lightbox aan/uit
    if(uitlegOn){
      // (v3.3.7) geen swipe-hint
      mode = 'help';
      helpFiltered = helpItems.slice();
      openAt(0);
    }else{
      if(mode === 'help') closeLb();
      mode = 'cards';
    }
  }

  function setShuffle(on){
    shuffleOn = !!on;
    setChip(shuffleBtn, shuffleOn);

    mode = 'cards';
    filtered = shuffleOn ? shuffle(data.slice()) : data.slice();
    render(filtered);
    closeLb();
  }

  // Start: beide uit
  setChip(shuffleBtn, false);
  setChip(uitlegBtn, false);
  document.body.classList.remove('show-intro');
  document.body.classList.remove('uitleg-open');

  if(shuffleBtn){
    shuffleBtn.addEventListener('click', () => setShuffle(!shuffleOn));
  }
  if(uitlegBtn){
    uitlegBtn.addEventListener('click', () => setUitleg(!uitlegOn));
  }

  // Mobiel: geen ✕ knop meer. Sluiten gaat via swipe-down (handler/kaart).

  // Houd altijd genoeg "safe space" boven de fixed pills (links-onder),
  // zodat tekst nooit onder de pills valt. Dynamisch (iOS safe-area + grootte).
  const updatePillsSafe = () => {
    const dock = document.querySelector('.pillsDock');
    if(!dock) return;
    const rect = dock.getBoundingClientRect();
    const h = Math.max(0, rect.height);
    // +6px ademruimte (compacter op mobiel)
    document.documentElement.style.setProperty('--pillsSafe', `${Math.ceil(h + 6)}px`);
  };
  window.addEventListener('resize', updatePillsSafe, {passive:true});
  window.addEventListener('orientationchange', updatePillsSafe, {passive:true});
  // eerste run
  requestAnimationFrame(updatePillsSafe);

  // ===============================
  // v3.3.50 – Mobile bottom-sheet gedrag (uitleg)
  // Eisen:
  // - Tijdens drag: sheet volgt vinger (geen opacity/fade/mee-bewegen UI)
  // - Animaties alleen bij loslaten
  // - Horizontaal swipen: licht (native scroll), Verticaal omlaag: zwaar met weerstand
  // - Drempel: onder = veer terug, boven = sluit onherroepelijk
  // - ✕ alleen zichtbaar als sheet volledig open & stabiel; verdwijnt bij drag-start
  // ===============================

  const introSheet = document.getElementById('mobileIntro');

  function offscreenY(){
    // Parkeer het sheet volledig buiten beeld (fool-proof op iOS/Safari)
    return Math.ceil(window.innerHeight * 1.10);
  }

  function forceCloseIntroSheet(immediate=true){
    if(!introSheet) return;
    document.body.classList.remove('show-intro');
    setSheetStable(false);
    introSheet.classList.remove('x-scrolling','is-stable');
    // Zorg dat de sheet echt buiten beeld staat en niets blokkeert
    if(immediate){
      introSheet.style.transition = 'none';
      introSheet.style.transform = `translateY(${offscreenY()}px)`;
    }else{
      introSheet.style.transform = `translateY(${offscreenY()}px)`;
    }
  }

  // SAFETY: start altijd met gesloten sheet (grid moet altijd zichtbaar zijn)
  window.addEventListener('DOMContentLoaded', () => {
    forceCloseIntroSheet(true);
  });

  // ✕ gedrag tijdens horizontaal bladeren:
  // - bij horizontaal scrollen (links/rechts) mag het kruisje even wegfaden
  // - bij verticale drag blijft hij sowieso verborgen (dat regelen we via .is-stable)
  // - zodra het scrollen stopt komt hij weer netjes terug (fade)
  (function setupIntroCloseFadeOnXScroll(){
    const introTrack = document.getElementById('introTrack');
    if(!introSheet || !introTrack) return;
    let t = null;
    introTrack.addEventListener('scroll', () => {
      if(!document.body.classList.contains('show-intro')) return;
      introSheet.classList.add('x-scrolling');
      document.body.classList.add('intro-xscroll');
      clearTimeout(t);
      t = setTimeout(() => {
        introSheet.classList.remove('x-scrolling');
        document.body.classList.remove('intro-xscroll');
      }, 220);
    }, {passive:true});
  })();
  let sheetAnim = null;

  function setSheetStable(stable){
    if(!introSheet) return;
    introSheet.classList.toggle('is-stable', !!stable);
    document.body.classList.toggle('intro-stable', !!stable);
  }

  function animateSheet(toY, {duration=160, overshoot=false} = {}){
    if(!introSheet) return;
    try{ sheetAnim?.cancel?.(); }catch(_e){}
    introSheet.style.transition = 'none';

    const from = getCurrentSheetY();
    const frames = overshoot
      ? [
          { transform: `translateY(${from}px)` },
          { transform: `translateY(${Math.min(-8, toY)}px)` },
          { transform: `translateY(${toY}px)` },
        ]
      : [
          { transform: `translateY(${from}px)` },
          { transform: `translateY(${toY}px)` },
        ];

    sheetAnim = introSheet.animate(frames, {
      duration,
      easing: 'cubic-bezier(.2,.9,.2,1)',
      fill: 'forwards'
    });
    sheetAnim.onfinish = () => {
      introSheet.style.transform = `translateY(${toY}px)`;
      sheetAnim = null;
    };
  }

  function getCurrentSheetY(){
    if(!introSheet) return 0;
    const t = getComputedStyle(introSheet).transform;
    if(!t || t === 'none') return 0;
    // matrix(a,b,c,d,tx,ty)
    const m = t.match(/matrix\([^,]+,[^,]+,[^,]+,[^,]+,[^,]+,\s*([^)]+)\)/);
    if(m) return parseFloat(m[1]) || 0;
    // matrix3d(..., ty)
    const m3 = t.match(/matrix3d\((?:[^,]+,){13}\s*([^,]+)\s*\)/);
    if(m3) return parseFloat(m3[1]) || 0;
    return 0;
  }

  function openIntroSheet(){
    if(!introSheet) return;
    document.body.classList.add('show-intro');
    // Start net onder beeld
    introSheet.style.transform = `translateY(${offscreenY()}px)`;
    setSheetStable(false);
    // Open in 120–180ms met mini-overshoot
    requestAnimationFrame(() => {
      animateSheet(0, {duration:160, overshoot:true});
      // Markeer als stabiel na de animatie
      setTimeout(() => setSheetStable(true), 170);
    });
  }

  function closeIntroSheet(){
    if(!introSheet) return;
    setSheetStable(false);
    // Sluiten iets sneller dan openen
    animateSheet(introSheet.getBoundingClientRect().height + 24, {duration:140, overshoot:false});
    // Na close: class weg (zodat layout/aria consistent is)
    setTimeout(() => {
      forceCloseIntroSheet(true);
    }, 145);
  }

  // --- Drag gedrag ---
  (function setupIntroSheetDrag(){
    if(!introSheet) return;
    const introTrack = document.getElementById('introTrack');
    // Swipes starten vaak op de kaarten/track zelf.
    // Als we de gesture direct aan de track hangen kan (met touch-action/scroll-snap)
    // de browser de verticale beweging overnemen (dan krijg je 'scroll' i.p.v. sheet-drag).
    // Daarom luisteren we op de SHEET (capture), zodat we altijd de beweging zien.
    // Horizontaal bladeren blijft native via de track; verticaal (omlaag) claimen we pas na beslissing.
    const dragEl = introSheet;
    let down = false;
    let armed = false;
    let decided = false;
    let vertical = false;
    let sx=0, sy=0;
    let currentY = 0;
    let threshold = 160;
    let lockedClose = false;

    const DEAD = 14; // 10–15px: bijna geen beweging

    function computeThreshold(){
      const h = Math.max(1, introSheet.getBoundingClientRect().height);
      // ~35% van sheet, met sane caps
      threshold = Math.max(120, Math.min(220, h * 0.35));
    }

    function setY(y){
      currentY = Math.max(0, y);
      introSheet.style.transform = `translateY(${currentY}px)`;
    }

    function resistance(d){
      // zwaar gevoel: eerst deadzone, daarna voelbaar meegeven
      const x = Math.max(0, d - DEAD);
      let y = x * 0.55;
      if(x > 220) y = 220 * 0.55 + (x - 220) * 0.25;
      return y;
    }

    function disableHorizontalScroll(){
      if(!introTrack) return;
      // tijdens verticale drag tijdelijk blokkeren zodat iOS/Android niet 'pakt' op horizontaal scrollen
      introTrack.dataset._ox = introTrack.style.overflowX || '';
      introTrack.style.overflowX = 'hidden';
      introTrack.dataset._ta = introTrack.style.touchAction || '';
      introTrack.style.touchAction = 'none';
    }
    function restoreHorizontalScroll(){
      if(!introTrack) return;
      if('_ox' in introTrack.dataset) introTrack.style.overflowX = introTrack.dataset._ox;
      if('_ta' in introTrack.dataset) introTrack.style.touchAction = introTrack.dataset._ta;
      delete introTrack.dataset._ox;
      delete introTrack.dataset._ta;
    }

    dragEl.addEventListener('pointerdown', (e) => {
      if(!document.body.classList.contains('show-intro')) return;
      // Start mag óók op de horizontale track (kaarten).
      // We beslissen pas bij de eerste beweging: horizontaal = bladeren, verticaal (omlaag) = sheet drag.
      // Ook niet op buttons (zoals ✕)
      if(e.target && e.target.closest && e.target.closest('button')){
        return;
      }

      down = true;
      armed = true;
      decided = false;
      vertical = false;
      lockedClose = false;
      sx = e.clientX;
      sy = e.clientY;
      currentY = 0;
      computeThreshold();
      // ✕ NIET verbergen bij pointerdown (anders verdwijnt hij ook bij zijdelings scrollen).
      // We verbergen ✕ pas zodra we zeker weten dat dit een verticale drag is.
      introSheet.style.transition = 'none';
      try{ dragEl.setPointerCapture?.(e.pointerId); }catch(_e){}
    }, {passive:true, capture:true});

    dragEl.addEventListener('pointermove', (e) => {
      if(!down || !armed) return;
      const dx = e.clientX - sx;
      const dy = e.clientY - sy;
      const ax = Math.abs(dx);
      const ay = Math.abs(dy);

      if(!decided){
        // Richtingbeslissing met duidelijke voorkeur:
        // - Eerst een kleine deadzone
        // - Daarna pas kiezen op basis van ratio (voorkomt dat mini-horizontale drift je verticale drag blokkeert)
        if(ax < 12 && ay < 12) return;
        if(ay > ax * 1.2){
          decided = true;
          vertical = true;
        }else if(ax > ay * 1.2){
          decided = true;
          vertical = false;
        }else{
          // nog ambigu: wacht op iets duidelijkere richting
          return;
        }
        if(!vertical){
          // Horizontaal: laat alles los (native scroll blijft licht)
          armed = false;
          down = false;
          setSheetStable(true);
          return;
        }
        // Verticaal: nu pas echt claimen — ✕ verdwijnt zodra de verticale drag start
        setSheetStable(false);
        disableHorizontalScroll();
      }

      // Alleen omlaag trekken
      if(dy <= 0){
        // Als we al over de drempel zijn: niet meer terug te trekken.
        if(lockedClose){
          setY(Math.max(threshold, currentY));
        }else{
          setY(0);
        }
        return;
      }

      // Prevent background scroll tijdens verticale drag
      try{ e.preventDefault(); }catch(_e){}

      let y = resistance(dy);

      // Drempel: boven = onherroepelijk (niet meer terug)
      if(y >= threshold){
        lockedClose = true;
        const over = y - threshold;
        y = threshold + over * 1.1; // lichte versnelling / snap-gevoel
      }
      if(lockedClose) y = Math.max(threshold, y);

      setY(y);
    }, {passive:false, capture:true});

    function release(){
      if(!down) return;
      down = false;
      restoreHorizontalScroll();
      if(!decided){
        // Geen drag: sheet blijft open
        setSheetStable(true);
        return;
      }
      if(!vertical){
        setSheetStable(true);
        return;
      }

      if(lockedClose || currentY >= threshold){
        // Onherroepelijk sluiten
        setSheetStable(false);
        closeIntroSheet();
        return;
      }
      // Altijd terugveren onder drempel
      animateSheet(0, {duration:150, overshoot:true});
      setTimeout(() => setSheetStable(true), 155);
    }

    dragEl.addEventListener('pointerup', release, {passive:true});
    dragEl.addEventListener('pointercancel', release, {passive:true});

    // --- Touch fallback (iOS/Safari): pointer-events + touch-action geven soms geen betrouwbare verticale drag.
    // We gebruiken dezelfde logica, maar dan met touchstart/move/end.
    let tActive = false;
    dragEl.addEventListener('touchstart', (e) => {
      if(!document.body.classList.contains('show-intro')) return;
      const touch = e.touches && e.touches[0];
      if(!touch) return;
      if(e.target && e.target.closest && e.target.closest('button')) return;

      tActive = true;
      down = true;
      armed = true;
      decided = false;
      vertical = false;
      lockedClose = false;
      sx = touch.clientX;
      sy = touch.clientY;
      currentY = 0;
      computeThreshold();
      // ✕ NIET verbergen bij touchstart (anders verdwijnt hij ook bij zijdelings scrollen).
      // We verbergen ✕ pas zodra we zeker weten dat dit een verticale drag is.
      introSheet.style.transition = 'none';
    }, {passive:true, capture:true});

    dragEl.addEventListener('touchmove', (e) => {
      if(!tActive || !down || !armed) return;
      const touch = e.touches && e.touches[0];
      if(!touch) return;
      const dx = touch.clientX - sx;
      const dy = touch.clientY - sy;
      const ax = Math.abs(dx);
      const ay = Math.abs(dy);

      if(!decided){
        // Richtingbeslissing met duidelijke voorkeur:
        // - Eerst een kleine deadzone
        // - Daarna pas kiezen op basis van ratio (voorkomt dat mini-horizontale drift je verticale drag blokkeert)
        if(ax < 12 && ay < 12) return;
        if(ay > ax * 1.2){
          decided = true;
          vertical = true;
        }else if(ax > ay * 1.2){
          decided = true;
          vertical = false;
        }else{
          // nog ambigu: wacht op iets duidelijkere richting
          return;
        }
        if(!vertical){
          // horizontaal: laat native scroll
          armed = false;
          down = false;
          setSheetStable(true);
          return;
        }
        // Verticaal: claimen — ✕ verbergen
        setSheetStable(false);
        disableHorizontalScroll();
      }

      if(!vertical) return;
            if(dy <= 0){
        // Als we al over de drempel zijn: niet meer terug te trekken.
        if(lockedClose){
          setY(Math.max(threshold, currentY));
        }else{
          setY(0);
        }
        return;
      }

      // Cruciaal: stop page scroll tijdens verticale drag
      e.preventDefault();

      let y = resistance(dy);
      if(y >= threshold){
        lockedClose = true;
        const over = y - threshold;
        y = threshold + over * 1.1;
      }
      if(lockedClose) y = Math.max(threshold, y);
      setY(y);
    }, {passive:false, capture:true});

    function touchRelease(){
      if(!tActive) return;
      tActive = false;
      release();
    }
    dragEl.addEventListener('touchend', touchRelease, {passive:true, capture:true});
    dragEl.addEventListener('touchcancel', touchRelease, {passive:true, capture:true});
  })();

  // Swipe-down verwijderd voor stabiliteit (v3.3.42)

// (v3.2) Geen extra "Uitleg/Verberg" header meer op mobiel.





/* ===============================
   v2.8 – Mobile uitleg-carousel vanuit JSON
   =============================== */
async function renderMobileIntro(){
  const section = document.getElementById('mobileIntro');
  const track = document.getElementById('introTrack');
  if(!section || !track) return;

  let data = null;

  // 1) Inline data (meest fool-proof)
  const el = document.getElementById('intro-json');
  if(el){
    try{ data = JSON.parse(el.textContent); }catch(e){ data = null; }
  }

  // 2) Fallback: fetch
  if(!data){
    try{
      const r = await fetch(withV(setPath('intro.json')), { cache:'no-store' });
      data = await r.json();
    }catch(e){
      return;
    }
  }
  if(!data || !Array.isArray(data.slides)) return;

  // Build cards
  track.innerHTML = '';

  const slides = data.slides.slice();
  const realCount = slides.length;

  // helper om één kaart te bouwen
  const buildCard = (s) => {
    // Google Maps-achtig: kaart (image) + info-vlak eronder dat subtiel mee kleurt.
    const art = document.createElement('article');
    art.className = 'introCard';
    art.dataset.intro = s.key || '';

    // === Top: kaart (afbeelding) ===
    const mediaCard = document.createElement('div');
    mediaCard.className = 'introMediaCard';

    const img = document.createElement('img');
    img.className = 'introImg';
    img.src = withV(setPath(s.img || ''));
    img.alt = s.alt || s.title || '';
    mediaCard.appendChild(img);

    // Thema-naam in het midden van de kaart (alleen thema-kaarten, niet de voorkant)
    if((s.key || '') !== 'cover' && (s.title || '').trim()){
      const theme = document.createElement('div');
      theme.className = 'introTheme';
      theme.textContent = s.title;
      mediaCard.appendChild(theme);
    }

    // === Bottom: info vlak (subtiel mee-kleurend) ===
    const info = document.createElement('div');
    info.className = 'introInfo';

    const text = document.createElement('div');
    text.className = 'introInfoText';
    text.textContent = s.body || '';
    info.appendChild(text);

    // Fallback tint (als parsing faalt)
    if(typeof s.tint === 'string' && s.tint.trim()){
      info.style.setProperty('--introTint', s.tint.trim());
    }

    // Auto-tint uit dominante kleur van SVG (same-origin)
    applyIntroTintFromSvg(img, info);

    art.appendChild(mediaCard);
    art.appendChild(info);
    return art;
  };

  // ---- kleurhelpers (dominante kleur uit SVG -> subtiele tint) ----
  function clamp01(n){ return Math.max(0, Math.min(1, n)); }

  function parseColorToRgb(c){
    if(!c) return null;
    c = String(c).trim().toLowerCase();
    if(c === 'none' || c === 'transparent') return null;
    // hex
    if(c[0] === '#'){
      let h = c.slice(1);
      if(h.length === 3) h = h.split('').map(ch => ch+ch).join('');
      if(h.length === 6){
        const r = parseInt(h.slice(0,2),16);
        const g = parseInt(h.slice(2,4),16);
        const b = parseInt(h.slice(4,6),16);
        if([r,g,b].some(v => Number.isNaN(v))) return null;
        return {r,g,b};
      }
      return null;
    }
    // rgb/rgba
    const m = c.match(/rgba?\(([^)]+)\)/);
    if(m){
      const parts = m[1].split(',').map(x => x.trim());
      const r = Number(parts[0]);
      const g = Number(parts[1]);
      const b = Number(parts[2]);
      if([r,g,b].some(v => Number.isNaN(v))) return null;
      // alpha check
      if(parts[3] != null){
        const a = Number(parts[3]);
        if(!Number.isNaN(a) && a <= 0.05) return null;
      }
      return {r,g,b};
    }
    return null;
  }

  function isMostlyWhite({r,g,b}){
    return r > 245 && g > 245 && b > 245;
  }

  // iOS/Safari-proof: gebruik een subtiele transparante tint (Maps-achtig)
  // in plaats van color-mix(). Dit geeft een "mee-kleurend" paneel zonder
  // dat het snel te hard wordt.
  function toRgba(rgb, a){
    const alpha = clamp01(a);
    return `rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, ${alpha})`;
  }

  async function dominantColorFromSvgUrl(url){
    try{
      const r = await fetch(url, { cache:'no-store' });
      const svg = await r.text();
      const counts = new Map();

      // 1) Probeer eerst een "achtergrond" rect te vinden (meestal het grootste vlak)
      // Dit voorkomt dat tekst (veel losse paths) de dominante kleur "wint".
      // We pakken de rect met de grootste (w*h) met een geldige fill.
      let bestRect = null;
      let bestArea = 0;
      for(const m of svg.matchAll(/<rect\b[^>]*>/gi)){
        const tag = m[0];
        const fillM = tag.match(/\bfill\s*=\s*['\"]([^'\"]+)['\"]/i);
        if(!fillM) continue;
        const rgb = parseColorToRgb(fillM[1]);
        if(!rgb || isMostlyWhite(rgb)) continue;

        const wM = tag.match(/\bwidth\s*=\s*['\"]([0-9.]+)(px)?['\"]/i);
        const hM = tag.match(/\bheight\s*=\s*['\"]([0-9.]+)(px)?['\"]/i);
        const w = wM ? Number(wM[1]) : NaN;
        const h = hM ? Number(hM[1]) : NaN;
        if(!Number.isFinite(w) || !Number.isFinite(h)) continue;
        const area = w * h;
        if(area > bestArea){
          bestArea = area;
          bestRect = rgb;
        }
      }
      if(bestRect){
        return bestRect;
      }

      const push = (raw) => {
        const rgb = parseColorToRgb(raw);
        if(!rgb) return;
        if(isMostlyWhite(rgb)) return;
        const key = `rgb(${rgb.r},${rgb.g},${rgb.b})`;
        counts.set(key, (counts.get(key) || 0) + 1);
      };

      // 2) Fallback: tel alle kleuren (werkt goed voor simpele SVG's)
      // fill="..."
      for(const m of svg.matchAll(/fill\s*=\s*['\"]([^'\"]+)['\"]/gi)) push(m[1]);
      // style="...fill: ..."
      for(const m of svg.matchAll(/fill\s*:\s*([^;"']+)/gi)) push(m[1]);
      // gradients stop-color
      for(const m of svg.matchAll(/stop-color\s*=\s*['\"]([^'\"]+)['\"]/gi)) push(m[1]);
      for(const m of svg.matchAll(/stop-color\s*:\s*([^;"']+)/gi)) push(m[1]);

      let best = null;
      let bestN = 0;
      for(const [k,n] of counts.entries()){
        if(n > bestN){ bestN = n; best = k; }
      }
      if(!best) return null;
      const mm = best.match(/rgb\((\d+),(\d+),(\d+)\)/);
      if(!mm) return null;
      return { r:Number(mm[1]), g:Number(mm[2]), b:Number(mm[3]) };
    }catch(e){
      return null;
    }
  }

  function applyIntroTintFromSvg(imgEl, infoEl){
    if(!imgEl || !infoEl) return;
    const url = imgEl.currentSrc || imgEl.src;
    if(!url) return;

    // Zodra image er is: fetch SVG en bepaal tint
    const run = async () => {
      const rgb = await dominantColorFromSvgUrl(url);
      if(!rgb) return;
      // Maps-achtig: lichte transparante tint van de dominante kleur.
      // (iets "groener" zichtbaar dan de vorige white-mix)
      const tint = toRgba(rgb, 0.14);
      infoEl.style.setProperty('--introTint', tint);
    };

    if(imgEl.complete) run();
    else imgEl.addEventListener('load', run, { once:true });
  }

  // (Infinity scroll) clones aan beide kanten zodat je "oneindig" door kan swipen
  const CLONE_N = Math.min(2, realCount);
  if(realCount > 1){
    for(let i=realCount-CLONE_N; i<realCount; i++){
      const c = buildCard(slides[i]);
      c.dataset.clone = '1';
      track.appendChild(c);
    }
  }

  for(const s of slides){
    track.appendChild(buildCard(s));
  }

  if(realCount > 1){
    for(let i=0; i<CLONE_N; i++){
      const c = buildCard(slides[i]);
      c.dataset.clone = '1';
      track.appendChild(c);
    }
  }

  // Hint text (optional)
  const hintEl = section.querySelector('.introHint');
  if(hintEl && typeof data.hint === 'string') hintEl.textContent = data.hint;

  // Infinity scroll: na layout (widths bekend) scroll naar eerste echte item
  if(realCount > 1){
    requestAnimationFrame(() => {
      const firstReal = track.querySelectorAll('.introCard')[CLONE_N];
      if(!firstReal) return;
      const gap = 14; // gelijk aan CSS
      const step = firstReal.getBoundingClientRect().width + gap;
      let jumping = false;

      // Startpositie: op eerste echte kaart
      track.scrollLeft = step * CLONE_N;

      const onScroll = () => {
        if(jumping) return;
        const max = step * (realCount + CLONE_N);
        const min = step * (CLONE_N - 1);
        const x = track.scrollLeft;

        // Te ver naar links -> spring naar dezelfde positie achteraan
        if(x <= min){
          jumping = true;
          track.scrollLeft = x + step * realCount;
          requestAnimationFrame(() => { jumping = false; });
        }
        // Te ver naar rechts -> spring naar dezelfde positie vooraan
        else if(x >= max){
          jumping = true;
          track.scrollLeft = x - step * realCount;
          requestAnimationFrame(() => { jumping = false; });
        }
      };

      track.addEventListener('scroll', onScroll, { passive:true });
    });
  }
}

// Fire & forget after DOM is ready
document.addEventListener('DOMContentLoaded', () => { renderMobileIntro(); });




// SAFETY: close button delegation (v3.3.28)
document.addEventListener('click', (e) => {
  const closeEl = e.target && (e.target.closest ? e.target.closest('.lbClose, .close') : null);
  const lb = document.getElementById('lb');
  if (!lb) return;
  if (lb.classList.contains('open') && closeEl) {
    e.preventDefault();
    e.stopPropagation();
    try { closeLb(); } catch(_) {}
  }
}, true);

// CLOSE DELEGATION v3.3.32: als de overlay open is, sluit altijd bij tap op #lbClose of .lbClose
document.addEventListener('pointerdown', (e) => {
  const lb = document.getElementById('lb');
  if (!lb || !lb.classList.contains('open')) return;
  const closeEl = e.target && (e.target.closest ? e.target.closest('#lbClose, .lbClose, .close') : null);
  if (!closeEl) return;
  e.preventDefault();
  e.stopPropagation();
  try { closeLb(); } catch(_) {}
}, true);


// KEIHARDE CLOSE FIX v3.3.38
(function(){
  const lb = document.getElementById('lb');
  const closeBtn = document.getElementById('lbClose');
  const closeHitbox = document.getElementById('lbCloseHitbox');
  if(!lb || !closeBtn || !closeHitbox) return;

  function positionCloseHitbox(){
    const r = closeBtn.getBoundingClientRect();
    closeHitbox.style.top = Math.round(r.top - 10) + 'px';
    closeHitbox.style.left = Math.round(r.left - 10) + 'px';
  }

  window.addEventListener('resize', positionCloseHitbox, {passive:true});
  window.addEventListener('scroll', positionCloseHitbox, {passive:true});

  function forceClose(e){
    e.preventDefault();
    e.stopPropagation();
    if(e.stopImmediatePropagation) e.stopImmediatePropagation();
    if(typeof closeLb === 'function') closeLb();
  }

  closeHitbox.addEventListener('pointerdown', forceClose, {capture:true});
  closeHitbox.addEventListener('click', forceClose, {capture:true});

  const obs = new MutationObserver(()=>{
    if(lb.classList.contains('open')) positionCloseHitbox();
  });
  obs.observe(lb, {attributes:true, attributeFilter:['class']});
})();


/* ------------------------------------------------------------
   CLOSE (opnieuw opgebouwd)
   - Eén centrale binding voor #lbClose en #lbCloseHitbox
   - Backdrop tap sluit ook (buiten .panel)
------------------------------------------------------------ */
(function(){
  const lb = document.getElementById('lb');
  const closeBtn = document.getElementById('lbClose');
  const hit = document.getElementById('lbCloseHitbox');
  if(!lb) return;

  function hardClose(){
    lb.classList.remove('open','dragging','closing','is-dragging','is-swiping');
    lb.style.transform = '';
    document.documentElement.style.overflow = '';
    document.body.style.overflow = '';
    document.body.style.touchAction = '';
    document.body.style.position = '';
    document.body.style.top = '';
  }

  function safeClose(e){
    if(e){
      e.preventDefault();
      e.stopPropagation();
      if(e.stopImmediatePropagation) e.stopImmediatePropagation();
    }
    try{
      if(typeof closeLb === 'function'){
        closeLb();
        // Als closeLb door iets vroegtijdig stopt, val dan terug.
        setTimeout(()=>{ if(lb.classList.contains('open')) hardClose(); }, 0);
      } else {
        hardClose();
      }
    }catch(_){
      hardClose();
    }
  }

  [closeBtn, hit].forEach(el=>{
    if(!el) return;
    el.addEventListener('touchstart', safeClose, {capture:true, passive:false});
    el.addEventListener('pointerdown', safeClose, {capture:true});
    el.addEventListener('click', safeClose, {capture:true});
  });

  // Backdrop klik/tap sluit (maar niet binnen de kaart/panel)
  document.addEventListener('pointerdown', (e)=>{
    if(!lb.classList.contains('open')) return;
    const insidePanel = e.target && e.target.closest && e.target.closest('.panel');
    const isClose = e.target && e.target.closest && e.target.closest('#lbClose,#lbCloseHitbox');
    if(!insidePanel && !isClose) safeClose(e);
  }, true);
})();


/* v3.3.50 – Horizontaal swipen in de uitleg gebeurt native via scroll-snap.
   Geen JS-gestures nodig (houdt het licht, vloeiend en conflictvrij). */


/* v3.3.42 – Harde swipe reset */
function resetSwipe(){
  document.body.style.touchAction = '';
}

const _origClose = window.closeLb;
window.closeLb = function(){
  resetSwipe();
  if(_origClose) _origClose();
};
